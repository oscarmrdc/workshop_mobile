const db = require("../models");
const Tutorial = db.tutorials;
const Op = db.Sequelize.Op;
var crypto = require('crypto');

// Find a single Tutorial with DNI v1
exports.findDNIv1 = (req, res) => {
  const dni = req.params.dni;
  var condition = dni ? { dni: { [Op.like]: `%${dni}%` } } : null;

  Tutorial.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    });
};

// Find a single Tutorial with DNI v2
exports.findDNIv2 = (req, res) => {
  const dni = req.params.dni;
  var condition = dni ? { dni: { [Op.eq]: `${dni}` } } : null;

  Tutorial.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    });
};


// Find a single Tutorial with DNI v3 SHA
exports.findshaDNIv3 = (req, res) => {
  const dni = req.params.dni;
  //var hashdni = crypto.createHash('sha256').update(dni).digest('hex');
  //console.log(hashdni);

  var condition = dni ? { hashdni: { [Op.eq]: `${dni}` } } : null;

  Tutorial.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    });
};


// Find a single Tutorial with DNI v4 AES
exports.findaesDNIv4 = (req, res) => {
  const dnicifrado = req.params.dni;
  
  //from https://gist.github.com/siwalikm/8311cf0a287b98ef67c73c1b03b47154
  let ENC_KEY = "bf3c199c2470cb477d907b1e0917c17b";
  let IV = "5183666c72eec9e4";
  var decrypt = ((encrypted) => {
      let decipher = crypto.createDecipheriv('aes-256-cbc', ENC_KEY, IV);
      let decrypted = decipher.update(encrypted, 'base64', 'utf8');
      return (decrypted + decipher.final('utf8'));
      enc = Buffer.from(val, "base64");
  });
  var dni = decrypt(dnicifrado);
  console.log(dni);


  var condition = dni ? { dni: { [Op.eq]: `${dni}` } } : null;

  Tutorial.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    });
};



// Find a single Tutorial with an id
exports.findOne = (req, res) => {
    const id = req.params.id;
  
    Tutorial.findByPk(id)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message: "Error retrieving Tutorial with id=" + id
        });
      });
  };

// Find all published Tutorials
exports.findAllPublished = (req, res) => {
    Tutorial.findAll({ where: { activo: true } })
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving tutorials."
        });
      });
  };
