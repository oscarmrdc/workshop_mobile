module.exports = app => {
    const tutorials = require("../controllers/tutorial.controller.js");
  
    var router = require("express").Router();
  
    // Retrieve all Tutorials
    //router.get("/", tutorials.findAll);

    // Retrieve all published Tutorials
    //router.get("/published", tutorials.findAllPublished);
  
    // Retrieve a single Tutorial with id
    //router.get("/:id", tutorials.findOne);

    // Retrieve a single Tutorial with dni
    router.get("/dniv1/:dni", tutorials.findDNIv1);
    router.get("/dniv2/:dni", tutorials.findDNIv2);
    router.get("/dniv3/:dni", tutorials.findshaDNIv3);
    router.get("/dniv4/:dni", tutorials.findaesDNIv4);
  
    app.use('/api/tutorials', router);
  };