module.exports = (sequelize, Sequelize) => {
    const Tutorial = sequelize.define("tutorial", {
      dni: {
        type: Sequelize.STRING
      },
      hashdni: {
        type: Sequelize.STRING
      },
      saldo: {
        type: Sequelize.STRING
      },
      activo: {
        type: Sequelize.BOOLEAN
      }
    });
  
    return Tutorial;
  };